# BASIC-BANKING-SYSTEM
I am excited to share my completed #Task1 given by TheSparksFoundation as Web Development Internship.

The Task was to create a #Basic Banking System.

This is a web application containing basic banking options i.e., transfer money between multiple users, showing details of users,showing  money balance etc.
It contains 10 dummy users.A new dummy user can also be created.

Flow of the Website: Home Page > View all Users > Select and View one User > Transfer Money > Select reciever > View all Users > View Transfer History.

Technology Used:
Front-End: HTML/CSS​/Bootstrap
Back-End: PHP​ /JavaScript​
Database : MySQL


Flow of the Website: Home Page > View all Users > Select and View one User > Transfer Money > Select reciever > View all Users > View Transfer History.
